import React from 'react';

/** Minimaler TableField-Renderer mit stabilen Keys (nur als Fallback, falls eure Datei Keys fehlte). */
type Col = { key: string; title: string; width?: number };
type Props = { columns: Col[]; rows: any[] };

export default function TableField({ columns, rows }: Props) {
  return (
    <div style={{ overflowX: 'auto', border: '1px solid #EAECF0', borderRadius: 8 }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            {columns.map((c, i) => (
              <th key={`${c.key || c.title || 'col'}-${i}`} style={{ textAlign: 'left', padding: 8, borderBottom: '1px solid #EAECF0', width: c.width }}>{c.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={`row-${ri}`}>
              {columns.map((c, ci) => (
                <td key={`cell-${ri}-${ci}`} style={{ padding: 8, borderTop: '1px solid #F2F4F7' }}>{String(r[c.key])}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
