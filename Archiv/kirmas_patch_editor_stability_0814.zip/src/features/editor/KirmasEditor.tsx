import React, { useMemo, useState } from 'react';
import { normalizeSurveySchema, type SurveySchema, type SurveyPage, type SurveySection, type SurveyBlock, type SurveyField } from './schemaNormalizer';

// SAFETY-FIRST Ersatz für den bisherigen Editor:
// - Verwendet normalizeSurveySchema -> pages ist IMMER ein Array
// - Greift defensiv zu (?? []), so dass "undefined.sections" nicht mehr auftritt
// - Verwendet STABILE keys für Pages/Sections/Blocks/Fields
// - Bietet eine einfache Möglichkeit, colSpan zu ändern (Dropdown)
// - Lässt sich später wieder gegen euren "vollen" Editor austauschen

type Props = {
  /** Das aktuelle (rohe) Schema – kann auch "krumm" sein. */
  schema?: any;
  /** Wird bei Änderungen am Schema aufgerufen. */
  onChange?: (next: SurveySchema) => void;
};

function keyOf(str: string | undefined, idx: number, prefix: string) {
  return (str && str.trim()) ? `${prefix}-${str.toLowerCase().replace(/\W+/g,'_')}-${idx}` : `${prefix}-${idx}`;
}

function FieldRow({ field, onChange }: { field: SurveyField; onChange: (f: SurveyField) => void }) {
  const [local, setLocal] = useState<SurveyField>(field);
  React.useEffect(() => setLocal(field), [field]);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr 1fr 120px', gap: 8, alignItems: 'center', padding: '6px 0', borderBottom: '1px dashed #eee' }}>
      <div><b>{local.label || local.name}</b> <span style={{ color: '#98A2B3' }}>({local.type})</span></div>
      <div style={{ color: '#475467' }}>{local.name}</div>
      <div>
        <label style={{ fontSize: 12, color: '#667085' }}>Breite</label><br/>
        <select value={local.colSpan ?? 12} onChange={e => { const v = Number(e.target.value); const next={ ...local, colSpan: v }; setLocal(next); onChange(next); }}>
          {[12, 9, 8, 6, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} / 12</option>)}
        </select>
      </div>
      <div style={{ fontSize: 12, color: '#667085' }}>{(local.required ? 'Pflichtfeld' : '')}</div>
    </div>
  );
}

export default function KirmasEditor(props: Props) {
  const raw = props.schema ?? {};
  const safeSchema: SurveySchema = useMemo(() => normalizeSurveySchema(raw), [raw]);
  const [schema, setSchema] = useState<SurveySchema>(safeSchema);
  React.useEffect(() => setSchema(safeSchema), [safeSchema]);

  const pages = schema.pages ?? [];
  const [activePage, setActivePage] = useState(0);
  const page: SurveyPage | undefined = pages[activePage];

  function updateField(pIdx: number, sIdx: number, bIdx: number, fIdx: number, nextField: SurveyField) {
    const next = JSON.parse(JSON.stringify(schema)) as SurveySchema;
    (((next.pages ?? [])[pIdx]?.sections ?? [])[sIdx]?.blocks ?? [])[bIdx].fields[fIdx] = nextField;
    setSchema(next);
    props.onChange?.(next);
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 16, padding: 16 }}>
      {/* Seitenliste */}
      <aside>
        <h3 style={{ marginTop: 0 }}>Seiten</h3>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {(pages ?? []).map((p, i) => (
            <li key={keyOf(p.title, i, 'page')}>
              <button
                onClick={() => setActivePage(i)}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  padding: '6px 8px',
                  borderRadius: 8,
                  border: '1px solid ' + (i === activePage ? '#155EEF' : '#EAECF0'),
                  background: i === activePage ? '#EFF4FF' : '#FFFFFF',
                  marginBottom: 6,
                  cursor: 'pointer'
                }}
              >
                {p.title || `Seite ${i + 1}`}
              </button>
            </li>
          ))}
        </ul>
      </aside>

      {/* Inhalt */}
      <main>
        <h2 style={{ marginTop: 0 }}>{page?.title ?? 'Unbenannte Seite'}</h2>

        {(page?.sections ?? []).map((s, sIdx) => (
          <section key={keyOf(s.title, sIdx, 'section')} style={{ border: '1px solid #EAECF0', borderRadius: 12, padding: 12, marginBottom: 16 }}>
            <h3 style={{ marginTop: 0 }}>{s.title || `Abschnitt ${sIdx + 1}`}</h3>

            {(s?.blocks ?? []).map((b, bIdx) => (
              <div key={keyOf(b.title, bIdx, 'block')} style={{ border: '1px dashed #EAECF0', borderRadius: 8, padding: 10, marginBottom: 10 }}>
                <div style={{ fontWeight: 600, marginBottom: 8 }}>{b.title || `Block ${bIdx + 1}`}</div>

                {/* Felder */}
                {(b?.fields ?? []).map((f, fIdx) => (
                  <FieldRow
                    key={keyOf(f.name || f.label, fIdx, 'field')}
                    field={f}
                    onChange={(nf) => updateField(activePage, sIdx, bIdx, fIdx, nf)}
                  />
                ))}
              </div>
            ))}
          </section>
        ))}
      </main>
    </div>
  );
}
