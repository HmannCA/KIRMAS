// server/src/jsonRepair.ts
export function stripCodeFences(s: string): string {
  if (!s) return s;
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) return fence[1].trim();
  return s.trim();
}

export function sanitizeQuotes(s: string): string {
  // ersetze typografische Anführungszeichen
  return s
    .replace(/[“”„‟‹›«»]/g, '"')
    .replace(/[‘’‚‛]/g, "'");
}

export function removeComments(s: string): string {
  // Entferne JS/JSON-Kommentare
  return s
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|\s)//.*$/gm, '$1');
}

export function removeTrailingCommas(s: string): string {
  // trailing comma vor } oder ]
  return s.replace(/,(\s*[}\]])/g, '$1');
}

export function extractLargestJson(s: string): string | null {
  // Versuche größtes JSON-Objekt/Array via Stack zu extrahieren
  const text = s;
  let best: { start: number, end: number } | null = null;

  const tryScan = (open: string, close: string) => {
    const stack: number[] = [];
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (ch === open) stack.push(i);
      else if (ch === close && stack.length) {
        const start = stack.pop()!;
        if (!stack.length) {
          // vollständiger Block
          best = { start, end: i };
          break;
        }
      }
    }
  };

  tryScan('{', '}');
  if (!best) tryScan('[', ']');
  if (!best) return null;
  return text.slice(best.start, best.end + 1);
}

export function repairJsonToString(input: string): string | null {
  if (!input) return null;
  let s = stripCodeFences(input);
  s = sanitizeQuotes(s);
  s = removeComments(s);
  // Wenn kein direktes JSON, versuche größtes Objekt zu isolieren
  if (!(s.trim().startsWith('{') || s.trim().startsWith('['))) {
    const largest = extractLargestJson(s);
    if (largest) s = largest;
  }
  s = removeTrailingCommas(s);

  // Heuristik: ersetze 'prop': in "prop":
  s = s.replace(/([{,\[]\s*)'([^'"]+?)'\s*:/g, '$1"$2":');
  // Heuristik: ersetze : 'value' in : "value"
  s = s.replace(/:\s*'([^'\\]*(?:\\.[^'\\]*)*)'/g, r': "$1"');

  // Letzter Versuch: Unicode-NBSP entfernen
  s = s.replace(/\u00A0/g, ' ');

  try {
    JSON.parse(s);
    return s;
  } catch {
    return null;
  }
}
