
This archive contains a patched `server/src/index.ts`:
- Adds `.js` extensions to relative ESM imports (nodenext compatible)
- Imports and mounts `attachDevstoreSurveyRoutes(app)`
- Serves `/devstore/*` statically from `server/data/*`

Files:
- index.patched.ts  -> place it at server/src/index.ts (backup your original first)
