
How to wire routes (TypeScript, Express):

1) Save file: server/src/routes/devstoreSurveys.ts

2) In your server/src/index.ts add:
--------------------------------------------------
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import path from 'path';
import { attachDevstoreSurveyRoutes } from './routes/devstoreSurveys';

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Mount routes (points to server/data/surveys/*.json by default)
attachDevstoreSurveyRoutes(app, {
  // rootDir: path.join(process.cwd(), 'server', 'data', 'surveys'), // default
  // routeBase: '/api/devstore/surveys', // default
});

// ... keep your other routes, e.g. /api/ai/synthesize

const port = process.env.PORT || 5174;
app.listen(port, () => console.log('Server listening on http://localhost:' + port));
--------------------------------------------------

3) Start your server (npm run dev). The following endpoints will be available:

- GET /api/devstore/surveys
- GET /api/devstore/surveys/list
- GET /api/devstore/surveys/:id

These endpoints will read JSON files from server/data/surveys/*.json
and return normalized list entries with id/title/version/updatedAt.
