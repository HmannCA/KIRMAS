export type SurveyField = {
  type: string;
  name: string;
  label?: string;
  required?: boolean;
  multiple?: boolean;
  options?: Array<string | { value: string; label: string }>;
  colSpan?: number;
  [k: string]: any;
};
export type SurveyBlock = { title?: string; fields: SurveyField[] };
export type SurveySection = { title?: string; blocks: SurveyBlock[] };
export type SurveyPage = { title?: string; sections: SurveySection[] };
export type SurveySchema = { title?: string; pages: SurveyPage[] };

type AnyRec = Record<string, any>;
const toArr = <T = any>(v: any): T[] => Array.isArray(v) ? v : (v != null ? [v] : []);

const normalizeField = (f: AnyRec): AnyRec => {
  const out: AnyRec = { ...(f || {}) };
  if (out.type === 'multiselect') { out.type = 'select'; out.multiple = true; }
  if (out.type === 'phone') out.type = 'tel';
  if (out.options && !Array.isArray(out.options)) out.options = toArr(out.options);
  if (typeof out.colSpan !== 'number') out.colSpan = 12;
  if (typeof out.name !== 'string' && typeof out.label === 'string') {
    out.name = out.label.toLowerCase().replace(/\W+/g, '_').replace(/^_+|_+$/g, '');
  }
  return out;
};

const normalizeBlock = (b: AnyRec): AnyRec => ({
  title: b?.title ?? 'Block',
  fields: toArr(b?.fields).map(normalizeField),
});

const normalizeSection = (s: AnyRec): AnyRec => ({
  title: s?.title ?? 'Abschnitt',
  blocks: toArr(s?.blocks).map(normalizeBlock),
});

const normalizePage = (p: AnyRec): AnyRec => ({
  title: p?.title ?? 'Seite',
  sections: toArr(p?.sections).map(normalizeSection),
});

export function normalizeSurveySchema(input: AnyRec): SurveySchema {
  if (!input || typeof input !== 'object') return { title: 'Erhebung', pages: [] };
  const candidate = (input.survey ?? (Array.isArray(input.surveys) ? input.surveys[0] : input)) as AnyRec;
  const pages = toArr(candidate?.pages ?? candidate?.page).map(normalizePage);
  return { title: candidate?.title ?? 'Erhebung', pages };
}
