import React from 'react';
import ModelPicker from './ModelPicker';
import { uploadDocuments, callAiSynthesis } from './aiClient';
import { normalizeSurveySchema } from '../editor/schemaNormalizer';

type AiPanelProps = {
  onApplySchema?: (schema: any) => void; // optional – falls Editor einen Callback übergibt
};

export default function AiPanel({ onApplySchema }: AiPanelProps) {
  const [provider, setProvider] = React.useState<'openai' | 'gemini'>('openai');
  const [model, setModel] = React.useState<string>('gpt-4o');
  const [allowSplit, setAllowSplit] = React.useState<boolean>(false);
  const [prompt, setPrompt] = React.useState<string>('Erhebung zu Wasserwerken im Landkreis: Stammdaten, Anlagen, Pufferkapazität, Notstrom, Personal, Erreichbarkeit.');
  const [docText, setDocText] = React.useState<string>('');
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string|undefined>();
  const [preview, setPreview] = React.useState<any|null>(null);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files ? Array.from(e.target.files) : [];
    if (!files.length) return;
    try {
      setBusy(true); setError(undefined);
      const r = await uploadDocuments(files);
      setDocText(r.text || '');
    } catch (e: any) {
      setError(e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  async function generate() {
    try {
      setBusy(true); setError(undefined); setPreview(null);
      const { ok, schema, error:apiErr, mock } = await callAiSynthesis({ provider, model, prompt, docText, allowSplit });
      if (ok && schema) {
        setPreview(schema);
      } else if (mock) {
        setPreview(mock);
        setError(apiErr || 'KI nicht konfiguriert – zeige MOCK.');
      } else {
        setError(apiErr || 'Unbekannter Fehler.');
      }
    } catch (e: any) {
      // Fallback auf Mock im Frontend – konsistent mit bestehendem Verhalten
      setError(e?.response?.error || e.message || String(e));
      setPreview({
        title: 'Beispielerhebung (Frontend-Mock)',
        pages: [{ title: 'Angaben', sections: [{ title: 'Allgemein', blocks: [{ title: 'Stammdaten', fields: [
          { type: 'text', name: 'name', label: 'Name', required: true },
          { type: 'select', name: 'typ', label: 'Typ', options: ['Wasserwerk','Pumpwerk'], multiple: false }
        ] }]}]}]
      });
    } finally {
      setBusy(false);
    }
  }

  function applyToEditor() {
    if (!preview) return;
    const normalized = normalizeSurveySchema(preview?.schema ?? preview);
    if (onApplySchema) onApplySchema(normalized);
    // zusätzlich ein globales Event, falls kein Callback verdrahtet ist
    const ev = new CustomEvent('kirmas:ai:apply', { detail: { schema: normalized } });
    window.dispatchEvent(ev);
  }

  return (
    <div style={{ display: 'grid', gap: 12 }}>
      <ModelPicker provider={provider} model={model} onProviderChange={setProvider} onModelChange={setModel} />

      <label style={{ display: 'block' }}>
        Prompt/Anforderung:
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={5} style={{ width: '100%' }} />
      </label>

      <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <label>
          Dokumente (PDF/DOCX/XLSX/CSV/TXT):
          <input type="file" multiple onChange={handleUpload}
                 accept=".pdf,.doc,.docx,.xlsx,.xls,.csv,.txt,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain" />
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <input type="checkbox" checked={allowSplit} onChange={e => setAllowSplit(e.target.checked)} />
          Split-Erhebungen erlauben
        </label>
        <button onClick={generate} disabled={busy}>{busy ? 'Erzeuge…' : 'Vorschau erzeugen'}</button>
        <button onClick={applyToEditor} disabled={!preview}>In Editor übernehmen</button>
      </div>

      {error && <div style={{ color: 'red' }}>Hinweis: {error}</div>}

      {docText && (
        <details>
          <summary>Ingest-Text (Kurzfassung)</summary>
          <pre style={{ whiteSpace: 'pre-wrap', maxHeight: 200, overflow: 'auto' }}>{docText.slice(0, 2000)}</pre>
        </details>
      )}

      {preview && (
        <details open>
          <summary>KI-Vorschau (JSON)</summary>
          <pre style={{ whiteSpace: 'pre-wrap', maxHeight: 360, overflow: 'auto' }}>{JSON.stringify(preview, null, 2)}</pre>
        </details>
      )}
    </div>
  );
}
