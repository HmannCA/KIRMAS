
import React from 'react';

export type SurveySchema = any;

export type AiPanelProps = {
  open: boolean;
  onClose: () => void;
  getSchema: () => SurveySchema;
  onApply: (next: SurveySchema, mode: 'replace'|'append'|'integrate') => void;
  onLoad?: (payload: { id: string; title: string; version?: number; schema: SurveySchema }) => void;
};

type Provider = 'openai'|'gemini';
type Mode = 'replace'|'append'|'integrate';

type SavedItem = { id: string; title: string; version?: number; updatedAt?: string };

const styles = {
  overlay: {
    position: 'fixed' as const,
    top: 0, right: 0, bottom: 0,
    width: '480px',
    maxWidth: '100vw',
    background: '#FFFFFF',
    borderLeft: '1px solid #EAECF0',
    boxShadow: '-8px 0 24px rgba(16,24,40,0.08)',
    zIndex: 50,
    display: 'flex',
    flexDirection: 'column' as const
  },
  header: {
    padding: '12px 16px',
    borderBottom: '1px solid #EAECF0',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between'
  },
  title: { fontWeight: 600, fontSize: 16, color: '#101828' },
  body: { padding: 16, overflowY: 'auto' as const, display: 'grid', gap: 12 },
  label: { fontSize: 12, color: '#475467', marginBottom: 4 },
  input: { width: '100%', border: '1px solid #D0D5DD', borderRadius: 8, padding: '8px 10px' },
  select: { width: '100%', border: '1px solid #D0D5DD', borderRadius: 8, padding: '8px 10px', background: '#fff' },
  textarea: { width: '100%', minHeight: 120, border: '1px solid #D0D5DD', borderRadius: 8, padding: 10, resize: 'vertical' as const },
  row: { display: 'flex', gap: 8, alignItems: 'center' },
  col: { display: 'grid', gap: 6 },
  section: { display: 'grid', gap: 8, border: '1px solid #EAECF0', borderRadius: 10, padding: 12 },
  card: { border: '1px solid #EAECF0', borderRadius: 10, padding: 12 },
  small: { fontSize: 12, color: '#475467' },
  primary: { background: '#0B5ED7', color: '#fff', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' },
  subtle: { background: '#F2F4F7', color: '#344054', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' },
  danger: { background: '#D92D20', color: '#fff', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' },
  listItem: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 8, borderBottom: '1px solid #F2F4F7' },
  badge: { padding: '2px 8px', borderRadius: 999, background: '#EFF8FF', color: '#175CD3', fontSize: 12 },
  busy: {
    position: 'absolute' as const, inset: 0, background: 'rgba(16,24,40,0.55)',
    display: 'grid', placeItems: 'center', color: '#fff'
  },
  busyCard: {
    background: '#0B5ED7', borderRadius: 12, padding: 16, width: '88%', maxWidth: 420,
    display: 'grid', gap: 8, textAlign: 'center' as const, animation: 'pulse 1.8s ease-in-out infinite'
  }
};

const BUSY_LINES = [
  'Die KI analysiert Ihre Vorgaben …',
  'Dokumente werden aufbereitet …',
  'Feldstruktur wird modelliert …',
  'Abhängigkeiten & Sichtbarkeiten werden geprüft …',
  'Datenbankkonformität wird sichergestellt …',
  'Erhebung wird qualitätsgesichert …'
];

function isJsonResponse(r: Response) {
  const ct = r.headers.get('content-type') || '';
  return ct.includes('application/json');
}

async function fetchJsonFlexible(input: RequestInfo, init?: RequestInit) {
  const r = await fetch(input, init);
  if (!r.ok) throw new Error(r.status + ' ' + r.statusText);
  if (!isJsonResponse(r)) throw new Error('NOT_JSON');
  return r.json();
}

async function tryEndpoints<T = any>(paths: string[]): Promise<T> {
  let lastErr: any;
  for (const p of paths) {
    try {
      const data = await fetchJsonFlexible(p);
      return data as T;
    } catch (e) {
      lastErr = e;
      continue;
    }
  }
  throw lastErr || new Error('No endpoint succeeded');
}

export default function AiPanel({ open, onClose, getSchema, onApply, onLoad }: AiPanelProps) {
  const [provider, setProvider] = React.useState<Provider>('openai');
  const [model, setModel] = React.useState<string>('gpt-5');
  const [mode, setMode] = React.useState<Mode>('replace');
  const [prompt, setPrompt] = React.useState<string>('Bitte die Erhebung präzise und datenbanktauglich modellieren. Wenn sinnvoll, in logisch getrennte Teil-Erhebungen splitten.');

  const [busy, setBusy] = React.useState(false);
  const [busyLine, setBusyLine] = React.useState(BUSY_LINES[0]);

  const [saved, setSaved] = React.useState<SavedItem[]>([]);
  const [error, setError] = React.useState<string | null>(null);

  // rotate busy lines while busy
  React.useEffect(() => {
    if (!busy) return;
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % BUSY_LINES.length;
      setBusyLine(BUSY_LINES[i]);
    }, 1200 + Math.floor(Math.random() * 800));
    return () => clearInterval(id);
  }, [busy]);

  // refresh saved list when panel opens
  React.useEffect(() => {
    if (!open) return;
    refreshList();
  }, [open]);

  async function refreshList() {
    try {
      setError(null);
      // try multiple endpoints for compatibility
      const rows = await tryEndpoints<SavedItem[]>([
        '/api/surveys',
        '/api/devstore/surveys',
        '/api/devstore/surveys/list'
      ]);
      // normalize & stable sort
      const norm = rows
        .filter(x => x && x.id && x.title)
        .map(x => ({ id: String(x.id), title: String(x.title), version: (x as any).version ?? undefined, updatedAt: (x as any).updatedAt ?? undefined }));
      norm.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
      setSaved(norm);
    } catch (e: any) {
      console.warn('refreshList failed', e);
      setError('Konnte gespeicherte Erhebungen nicht laden.');
      setSaved([]);
    }
  }

  function modelsFor(p: Provider) {
    if (p === 'openai') return ['gpt-5', 'gpt-4o'];
    return ['gemini-2.5-pro', 'gemini-2.5-flash'];
  }

  React.useEffect(() => {
    setModel(modelsFor(provider)[0]);
  }, [provider]);

  async function runSynthesis() {
    setBusy(true);
    setError(null);
    try {
      const current = getSchema();
      const body = {
        prompt,
        mode,
        provider,
        model,
        schema: current
      };
      const r = await fetch('/api/ai/synthesize?mode=' + encodeURIComponent(mode), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (!r.ok) {
        if (r.status === 422) throw new Error('KI-Antwort war nicht gültiges JSON (422).');
        throw new Error('Serverfehler: ' + r.status + ' ' + r.statusText);
      }
      const data = await r.json();
      if (!data || !data.schema) throw new Error('Server lieferte kein { schema }.');
      onApply(data.schema, mode);
    } catch (e: any) {
      console.error(e);
      setError(e?.message || 'Unbekannter Fehler bei der KI-Synthese.');
    } finally {
      setBusy(false);
    }
  }

  async function handleLoad(id: string) {
    try {
      setError(null);
      // try to fetch detail from several endpoints
      const payload = await (async () => {
        const tryJson = async (p: string) => {
          const jr = await fetch(p);
          if (!jr.ok) throw new Error(jr.status + ' ' + jr.statusText);
          const ct = jr.headers.get('content-type') || '';
          if (!ct.includes('application/json')) throw new Error('NOT_JSON');
          return jr.json();
        };
        const tries = [
          `/api/surveys/${encodeURIComponent(id)}`,
          `/api/devstore/surveys/${encodeURIComponent(id)}`,
          `/api/devstore/surveys/get?id=${encodeURIComponent(id)}`
        ];
        let lastErr: any;
        for (const t of tries) {
          try {
            return await tryJson(t);
          } catch (e) { lastErr = e; }
        }
        throw lastErr || new Error('Keine GET-Route fand Daten.');
      })();
      const title = String(payload.title || 'Ohne Titel');
      const version = payload.version ?? undefined;
      const schema = payload.schema || payload.definition || payload.data || payload; // be lenient
      if (onLoad) {
        onLoad({ id, title, version, schema });
      } else {
        // Fallback: pack __id in schema and replace
        const next = { ...(schema || {}), __id: id, __title: title, __version: version };
        onApply(next, 'replace');
      }
      onClose();
    } catch (e: any) {
      console.error(e);
      setError('Konnte Erhebung nicht laden.');
    }
  }

  if (!open) return null;

  return (
    <aside style={styles.overlay} role="dialog" aria-label="KI-Assistent">
      <div style={styles.header}>
        <div style={styles.title}>KI-Assistent</div>
        <div className="row" style={{ display:'flex', gap:8 }}>
          <button style={styles.subtle} onClick={onClose}>Schließen</button>
          <button style={styles.primary} onClick={runSynthesis}>Erhebung erzeugen</button>
        </div>
      </div>

      <div style={styles.body}>
        <div style={styles.section}>
          <div style={styles.row}>
            <div style={{ flex: 1 }}>
              <div style={styles.label}>KI-Anbieter</div>
              <select
                style={styles.select}
                value={provider}
                onChange={e => setProvider(e.target.value as Provider)}
              >
                <option value="openai">OpenAI</option>
                <option value="gemini">Google Gemini</option>
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <div style={styles.label}>Modell</div>
              <select
                style={styles.select}
                value={model}
                onChange={e => setModel(e.target.value)}
              >
                {modelsFor(provider).map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
          </div>

          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='replace'} onChange={()=>setMode('replace')} />
              <span>Neu erstellen (ersetzen)</span>
            </label>
          </div>
          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='append'} onChange={()=>setMode('append')} />
              <span>An bestehende Erhebung anhängen</span>
            </label>
          </div>
          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='integrate'} onChange={()=>setMode('integrate')} />
              <span>Intelligent in bestehende integrieren</span>
            </label>
          </div>

          <div style={styles.col}>
            <div style={styles.label}>Auftrag an die KI</div>
            <textarea
              style={styles.textarea}
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="Beschreibe das Ziel, Dokumente etc. (Erstellung kann einige Minuten dauern)."
            />
            <div style={styles.small}>
              Hinweis: Die Erstellung kann einige Minuten dauern. Das System bleibt währenddessen aktiv – bitte nicht schließen.
            </div>
          </div>
        </div>

        <div style={styles.section}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontWeight: 600, color: '#101828' }}>Gespeicherte Erhebungen</div>
            <button style={styles.subtle} onClick={refreshList}>Aktualisieren</button>
          </div>
          <div style={styles.card}>
            {error && <div style={{ color:'#D92D20', marginBottom:8 }}>{error}</div>}
            <div style={{ display:'grid' }}>
              {saved.length === 0 && (
                <div style={styles.small}>Noch keine Erhebungen gespeichert.</div>
              )}
              {saved.map(item => (
                <div key={item.id} style={styles.listItem}>
                  <div style={{ display:'grid' }}>
                    <div style={{ fontWeight: 600 }}>{item.title}</div>
                    <div style={{ fontSize: 12, color:'#475467' }}>
                      ID: <span style={{ fontFamily:'monospace' }}>{item.id}</span>
                      {item.version != null && <span> · Version {item.version}</span>}
                      {item.updatedAt && <span> · {new Date(item.updatedAt).toLocaleString()}</span>}
                    </div>
                  </div>
                  <button style={styles.primary} onClick={()=>handleLoad(item.id)}>Laden</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {busy && (
        <div style={styles.busy}>
          <div style={styles.busyCard as any}>
            <div style={{ fontWeight: 700 }}>KI arbeitet …</div>
            <div>{busyLine}</div>
            <div style={{ fontSize: 12, opacity: 0.9 }}>Bitte haben Sie einen Moment Geduld – die Erstellung kann einige Minuten dauern.</div>
          </div>
        </div>
      )}
    </aside>
  );
}
