import React from 'react';
import ModelPicker from './ModelPicker';
import { uploadDocuments, callAiSynthesis } from './aiClient';
import { normalizeSurveySchema } from '../editor/schemaNormalizer';

export type AiPanelProps = {
  /** Sichtbarkeit wird vom Editor gesteuert. Wenn nicht gesetzt, ist das Panel sichtbar. */
  open?: boolean;
  /** Wird beim Schließen-Klick aufgerufen (z. B. Modal schließen). */
  onClose?: () => void;
  /** Optional: aktuelles Schema aus dem Editor abrufen (für spätere Features). */
  getSchema?: () => any;
  /** Schema in den Editor übernehmen (vom Editor erwartet). */
  onApply?: (next: any) => void;
  /** Rückwärtskompatibel: alternativ kann auch onApplySchema verwendet werden. */
  onApplySchema?: (schema: any) => void;
};

export default function AiPanel(props: AiPanelProps) {
  const {
    open = true,
    onClose,
    onApply,
    onApplySchema,
  } = props;

  if (!open) return null;

  const [provider, setProvider] = React.useState<'openai' | 'gemini'>('openai');
  const [model, setModel] = React.useState<string>('gpt-4o');
  const [allowSplit, setAllowSplit] = React.useState<boolean>(false);
  const [prompt, setPrompt] = React.useState<string>('Erhebung zu Wasserwerken im Landkreis: Stammdaten, Anlagen, Pufferkapazität, Notstrom, Personal, Erreichbarkeit.');
  const [docText, setDocText] = React.useState<string>('');
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string|undefined>();
  const [preview, setPreview] = React.useState<any|null>(null);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files ? Array.from(e.target.files) : [];
    if (!files.length) return;
    try {
      setBusy(true); setError(undefined);
      const r = await uploadDocuments(files);
      setDocText(r.text || '');
    } catch (e: any) {
      setError(e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  async function generate() {
    try {
      setBusy(true); setError(undefined); setPreview(null);
      const r = await callAiSynthesis({ provider, model, prompt, docText, allowSplit });
      // r kann { ok, schema } oder { error, mock } sein
      if (r?.ok && r?.schema) {
        setPreview(r.schema);
      } else if (r?.mock) {
        setPreview(r.mock);
        setError(r?.error || 'KI nicht konfiguriert – zeige MOCK.');
      } else {
        setError(r?.error || 'Unbekannter Fehler.');
      }
    } catch (e: any) {
      setError(e?.response?.error || e.message || String(e));
      setPreview({
        title: 'Beispielerhebung (Frontend-Mock)',
        pages: [{ title: 'Angaben', sections: [{ title: 'Allgemein', blocks: [{ title: 'Stammdaten', fields: [
          { type: 'text', name: 'name', label: 'Name', required: true },
          { type: 'select', name: 'typ', label: 'Typ', options: ['Wasserwerk','Pumpwerk'], multiple: false }
        ] }]}]}]
      });
    } finally {
      setBusy(false);
    }
  }

  function applyToEditor() {
    if (!preview) return;
    const normalized = normalizeSurveySchema(preview?.schema ?? preview);
    // Bevorzugt die vom Editor erwartete Prop
    if (onApply) onApply(normalized);
    else if (onApplySchema) onApplySchema(normalized);
    else {
      // Zur Sicherheit: globales Event
      const ev = new CustomEvent('kirmas:ai:apply', { detail: { schema: normalized } });
      window.dispatchEvent(ev);
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.35)',
        display: 'grid',
        placeItems: 'center',
        zIndex: 1000
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
    >
      <div style={{ background: 'white', width: 'min(980px, 92vw)', maxHeight: '90vh', overflow: 'auto', borderRadius: 8, padding: 16, boxShadow: '0 12px 40px rgba(0,0,0,0.25)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <h3 style={{ margin: 0 }}>KI-Assistent – Erhebung generieren</h3>
          <button onClick={onClose} aria-label="Schließen">✕</button>
        </div>

        <div style={{ display: 'grid', gap: 12 }}>
          <ModelPicker provider={provider} model={model} onProviderChange={setProvider} onModelChange={setModel} />

          <label style={{ display: 'block' }}>
            Prompt/Anforderung:
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={5} style={{ width: '100%' }} />
          </label>

          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <label>
              Dokumente (PDF/DOCX/XLSX/CSV/TXT):
              <input
                type="file"
                multiple
                onChange={handleUpload}
                accept=".pdf,.doc,.docx,.xlsx,.xls,.csv,.txt,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain"
              />
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <input type="checkbox" checked={allowSplit} onChange={e => setAllowSplit(e.target.checked)} />
              Split-Erhebungen erlauben
            </label>
            <button onClick={generate} disabled={busy}>{busy ? 'Erzeuge…' : 'Vorschau erzeugen'}</button>
            <button onClick={applyToEditor} disabled={!preview}>In Editor übernehmen</button>
          </div>

          {error && <div style={{ color: 'red' }}>Hinweis: {error}</div>}

          {docText && (
            <details>
              <summary>Ingest-Text (Kurzfassung)</summary>
              <pre style={{ whiteSpace: 'pre-wrap', maxHeight: 200, overflow: 'auto' }}>{docText.slice(0, 2000)}</pre>
            </details>
          )}

          {preview && (
            <details open>
              <summary>KI-Vorschau (JSON)</summary>
              <pre style={{ whiteSpace: 'pre-wrap', maxHeight: 360, overflow: 'auto' }}>{JSON.stringify(preview, null, 2)}</pre>
            </details>
          )}
        </div>
      </div>
    </div>
  );
}
