import React from 'react';

type Opt = string | { value: string; label: string };

function slugify(s: string): string {
  return (s || '')
    .trim()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[ß]/g, 'ss')
    .replace(/[ä]/g, 'ae')
    .replace(/[ö]/g, 'oe')
    .replace(/[ü]/g, 'ue')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function toObjects(value: Opt[]): { value: string; label: string }[] {
  const out: { value: string; label: string }[] = [];
  for (const o of (value || [])) {
    if (o == null) continue;
    if (typeof o === 'string') out.push({ value: slugify(o), label: o });
    else {
      const v = (o.value ?? slugify(o.label ?? 'option')) + '';
      const l = (o.label ?? o.value ?? '') + '';
      out.push({ value: v, label: l });
    }
  }
  return out;
}

export default function SelectOptionsEditor({
  value,
  onChange
}:{
  value: Opt[];
  onChange: (next: { value: string; label: string }[]) => void;
}){
  const [mode, setMode] = React.useState<'advanced'|'simple'>(() => {
    return (value || []).some(v => typeof v === 'object') ? 'advanced' : 'simple';
  });

  const [text, setText] = React.useState<string>(() => {
    const rows = toObjects(value || []);
    return rows.map(r => (r.label === r.value ? r.label : `${r.label} | ${r.value}`)).join('\n');
  });

  const [rows, setRows] = React.useState<{value:string; label:string}[]>(() => toObjects(value || []));

  React.useEffect(() => {
    if (mode === 'advanced') onChange(rows);
    else {
      const list: {value:string; label:string}[] = [];
      for (const rawLine of (text || '').split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line) continue;
        const m = line.match(/^(.+?)[\|=](.+)$/);
        if (m) {
          const label = m[1].trim();
          const value = m[2].trim() || slugify(label);
          list.push({ label, value });
        } else {
          const label = line;
          list.push({ label, value: slugify(label) });
        }
      }
      onChange(list);
    }
  }, [mode, text, rows]);

  function addRow(){
    setRows(r => [...r, { label: 'Option', value: 'option' }]);
  }
  function removeRow(i:number){
    setRows(r => r.filter((_,idx)=> idx!==i));
  }
  function updateRow(i:number, patch: Partial<{label:string; value:string}>){
    setRows(r => r.map((row,idx)=> idx===i ? { ...row, ...patch, value: patch.label!==undefined ? slugify(patch.label) : (patch.value ?? row.value) } : row));
  }

  return (
    <div style={{display:'grid', gap:8}}>
      <div className="row" style={{ gap:8, alignItems:'center' }}>
        <label className="row" style={{ gap:6 }}>
          <input type="radio" checked={mode==='advanced'} onChange={()=>setMode('advanced')} />
          <span>Erweitert (Label &amp; Value je Zeile)</span>
        </label>
        <label className="row" style={{ gap:6 }}>
          <input type="radio" checked={mode==='simple'} onChange={()=>setMode('simple')} />
          <span>Einfach (eine Option je Zeile)</span>
        </label>
      </div>

      {mode==='advanced' ? (
        <div style={{border:'1px solid #EAECF0', borderRadius:8}}>
          <table className="kirmas-table" style={{ width:'100%', borderCollapse:'collapse' }}>
            <colgroup>
              <col style={{width:'55%'}} />
              <col style={{width:'35%'}} />
              <col style={{width:'10%'}} />
            </colgroup>
            <thead>
              <tr><th>Label</th><th>Value</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i}>
                  <td><input className="kirmas-input" value={r.label} onChange={e=>updateRow(i,{label:e.target.value})} /></td>
                  <td><input className="kirmas-input" value={r.value} onChange={e=>updateRow(i,{value:e.target.value})} /></td>
                  <td><button className="btn" onClick={()=>removeRow(i)}>–</button></td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3}>
                  <div className="row" style={{justifyContent:'flex-end'}}>
                    <button className="btn" onClick={addRow}>+ Option</button>
                  </div>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      ) : (
        <textarea
          className="kirmas-textarea"
          placeholder="Eine Option pro Zeile. Optional: „Label | value“"
          value={text}
          onChange={e=>setText(e.target.value)}
        />
      )}
    </div>
  );
}
