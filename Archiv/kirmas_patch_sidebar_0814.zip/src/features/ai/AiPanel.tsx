import React from 'react';
import ModelPicker from './ModelPicker';
import { uploadDocuments, callAiSynthesis } from './aiClient';
import { normalizeSurveySchema } from '../editor/schemaNormalizer';

export type AiPanelProps = {
  open?: boolean;
  onClose?: () => void;
  getSchema?: () => any;
  /** Vom Editor erwartet: Schema anwenden. 2. Argument = Modus ('replace'|'append'|'smart-merge') */
  onApply?: (next: any, mode?: 'replace' | 'append' | 'smart-merge') => void;
  onApplySchema?: (schema: any) => void;
};

type Mode = 'replace' | 'append' | 'smart-merge';

export default function AiPanel(props: AiPanelProps) {
  const { open = true, onClose, onApply, onApplySchema } = props;
  if (!open) return null;

  const [provider, setProvider] = React.useState<'openai' | 'gemini'>('openai');
  const [model, setModel] = React.useState<string>('gpt-4o');
  const [allowSplit, setAllowSplit] = React.useState<boolean>(false);
  const [mode, setMode] = React.useState<Mode>('replace');
  const [prompt, setPrompt] = React.useState<string>('Erhebung zu Wasserwerken: Stammdaten, Adressen, Ansprechpartner, Notstrom, Kapazitäten, Erreichbarkeit.');
  const [docText, setDocText] = React.useState<string>('');
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string|undefined>();
  const [preview, setPreview] = React.useState<any|null>(null);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files ? Array.from(e.target.files) : [];
    if (!files.length) return;
    try {
      setBusy(true); setError(undefined);
      const r = await uploadDocuments(files);
      setDocText(r.text || '');
    } catch (e: any) {
      setError(e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  async function generate() {
    try {
      setBusy(true); setError(undefined); setPreview(null);
      const r = await callAiSynthesis({ provider, model, prompt, docText, allowSplit });
      if (r?.ok && r?.schema) {
        setPreview(r.schema);
      } else if (r?.mock) {
        setPreview(r.mock);
        setError(r?.error || 'KI nicht konfiguriert – zeige MOCK.');
      } else {
        setError(r?.error || 'Unbekannter Fehler.');
      }
    } catch (e: any) {
      setError(e?.response?.error || e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  function applyToEditor() {
    if (!preview) return;
    const normalized = normalizeSurveySchema(preview?.schema ?? preview);
    if (onApply) onApply(normalized, mode);
    else if (onApplySchema) onApplySchema(normalized);
    else {
      const ev = new CustomEvent('kirmas:ai:apply', { detail: { schema: normalized, mode } });
      window.dispatchEvent(ev);
    }
    onClose?.();
  }

  return (
    <div aria-hidden={!open} style={backdropStyle} onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}>
      <aside style={drawerStyle} role="dialog" aria-modal="true" aria-label="KI-Assistent">
        <div style={headerStyle}>
          <div>
            <h3 style={{ margin: 0, fontSize: 18 }}>KI-Assistent</h3>
            <div style={{ color: '#667085', fontSize: 12 }}>Erhebung generieren & übernehmen</div>
          </div>
          <button onClick={onClose} aria-label="Schließen" style={iconBtn}>✕</button>
        </div>

        <div style={{ display: 'grid', gap: 12 }}>
          <ModelPicker provider={provider} model={model} onProviderChange={setProvider} onModelChange={setModel} />

          <div style={card}>
            <label style={label}>Prompt/Anforderung</label>
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={6} style={textarea} />
            <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginTop: 8, flexWrap: 'wrap' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <input type="checkbox" checked={allowSplit} onChange={e => setAllowSplit(e.target.checked)} />
                Split-Erhebungen erlauben
              </label>

              <label>
                Dokumente (PDF/DOCX/XLSX/CSV/TXT)
                <input
                  type="file"
                  multiple
                  onChange={handleUpload}
                  accept=".pdf,.doc,.docx,.xlsx,.xls,.csv,.txt,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,text/plain"
                  style={{ display: 'block', marginTop: 6 }}
                />
              </label>
            </div>

            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <button onClick={generate} disabled={busy} style={primaryBtn}>{busy ? 'Erzeuge…' : 'Vorschau erzeugen'}</button>
              <button onClick={applyToEditor} disabled={!preview} style={secondaryBtn}>In Editor übernehmen</button>
            </div>
          </div>

          <div style={card}>
            <label style={label}>Einfügemodus</label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <ModePill active={mode==='replace'} onClick={() => setMode('replace')} label="Komplett ersetzen" hint="Bestehende Erhebung wird ersetzt" />
              <ModePill active={mode==='append'} onClick={() => setMode('append')} label="Anhängen" hint="Neue Seiten/Blöcke anhängen" />
              <ModePill active={mode==='smart-merge'} onClick={() => setMode('smart-merge')} label="Intelligent einfügen" hint="Versucht, Bereiche passend einzugliedern" />
            </div>
          </div>

          {docText && (
            <details style={card}>
              <summary style={{ cursor: 'pointer' }}>Ingest-Text (Kurzfassung)</summary>
              <pre style={pre}>{docText.slice(0, 2000)}</pre>
            </details>
          )}

          {preview && (
            <details open style={card}>
              <summary style={{ cursor: 'pointer' }}>KI-Vorschau (JSON)</summary>
              <pre style={pre}>{JSON.stringify(preview, null, 2)}</pre>
            </details>
          )}

          {error && <div style={{ ...card, color: '#B42318', background: '#FEF3F2', borderColor: '#FEE4E2' }}>Hinweis: {error}</div>}
        </div>
      </aside>
    </div>
  );
}

function ModePill({ active, onClick, label, hint }: { active: boolean; onClick: () => void; label: string; hint?: string }) {
  return (
    <button onClick={onClick}
      style={{
        padding: '6px 10px',
        borderRadius: 999,
        border: `1px solid ${active ? '#155EEF' : '#D0D5DD'}`,
        background: active ? '#EFF4FF' : '#FFFFFF',
        fontSize: 12,
        cursor: 'pointer'
      }}>
      <div style={{ fontWeight: 600 }}>{label}</div>
      {hint && <div style={{ fontSize: 10, color: '#667085' }}>{hint}</div>}
    </button>
  );
}

// --- Styles ---
const backdropStyle: React.CSSProperties = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(17, 24, 39, 0.38)',
  display: 'grid',
  gridTemplateColumns: '1fr auto',
  zIndex: 1000
};
const drawerStyle: React.CSSProperties = {
  width: '520px',
  height: '100vh',
  background: '#FFFFFF',
  borderLeft: '1px solid #EAECF0',
  padding: '16px',
  overflow: 'auto',
  boxShadow: '0 8px 30px rgba(0,0,0,0.25)'
};
const headerStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  marginBottom: 8,
  position: 'sticky',
  top: 0,
  background: '#FFFFFF',
  paddingBottom: 8,
  zIndex: 2
};
const iconBtn: React.CSSProperties = {
  border: '1px solid #D0D5DD',
  borderRadius: 8,
  background: '#FFFFFF',
  cursor: 'pointer',
  width: 32,
  height: 32
};
const card: React.CSSProperties = {
  border: '1px solid #EAECF0',
  borderRadius: 12,
  padding: 12,
  background: '#FFFFFF'
};
const label: React.CSSProperties = { fontSize: 12, color: '#667085', display: 'block', marginBottom: 6 };
const textarea: React.CSSProperties = { width: '100%', resize: 'vertical', minHeight: 120, fontFamily: 'inherit' };
const pre: React.CSSProperties = { whiteSpace: 'pre-wrap', maxHeight: 360, overflow: 'auto', margin: 0 };
const primaryBtn: React.CSSProperties = { padding: '8px 12px', borderRadius: 8, border: '1px solid #155EEF', background: '#155EEF', color: 'white', cursor: 'pointer' };
const secondaryBtn: React.CSSProperties = { padding: '8px 12px', borderRadius: 8, border: '1px solid #D0D5DD', background: 'white', cursor: 'pointer' };
