export type SurveyField = {
  type: string;
  name: string;
  label?: string;
  required?: boolean;
  multiple?: boolean;
  options?: Array<string | { value: string; label: string }>;
  colSpan?: number;
  [k: string]: any;
};
export type SurveyBlock = { title?: string; fields: SurveyField[] };
export type SurveySection = { title?: string; blocks: SurveyBlock[] };
export type SurveyPage = { title?: string; sections: SurveySection[] };
export type SurveySchema = { title?: string; pages: SurveyPage[] };

type AnyRec = Record<string, any>;
const toArr = <T = any>(v: any): T[] => Array.isArray(v) ? v : (v != null ? [v] : []);

const KN: Record<string, number> = {
  // Adressdaten
  'plz': 4, 'postal_code': 4, 'postcode': 4,
  'ort': 8, 'city': 8, 'town': 8,
  'straße': 9, 'strasse': 9, 'street': 9,
  'hausnummer': 3, 'hnr': 3, 'house_number': 3, 'number': 3,
  // Kontakt
  'telefon': 4, 'tel': 4, 'phone': 4,
  'mobil': 4, 'handy': 4, 'mobile': 4, 'mobile_phone': 4,
  'email': 4, 'e-mail': 4, 'mail': 4,
  // Zahlen
  'kapazität': 6, 'kapazitaet': 6, 'capacity': 6,
  'durchsatz': 6, 'throughput': 6
};

function inferColSpanByName(name?: string, fallback = 12): number {
  if (!name) return fallback;
  const n = name.toLowerCase();
  for (const k of Object.keys(KN)) {
    if (n.includes(k)) return KN[k];
  }
  return fallback;
}

function normalizeField(f: AnyRec): SurveyField {
  const out: SurveyField = { ...(f || {}) } as SurveyField;
  if (out.type === 'multiselect') { out.type = 'select'; out.multiple = true; }
  if (out.type === 'phone') out.type = 'tel';
  if (out.options && !Array.isArray(out.options)) out.options = toArr(out.options);
  if (typeof out.colSpan !== 'number') out.colSpan = inferColSpanByName(out.name || out.label);
  if (typeof out.name !== 'string' && typeof out.label === 'string') {
    out.name = out.label.toLowerCase().replace(/\W+/g, '_').replace(/^_+|_+$/g, '');
  }
  return out;
}

function normalizeBlock(b: AnyRec): SurveyBlock {
  return {
    title: b?.title ?? 'Block',
    fields: toArr(b?.fields).map(normalizeField),
  };
}

function normalizeSection(s: AnyRec): SurveySection {
  return {
    title: s?.title ?? 'Abschnitt',
    blocks: toArr(s?.blocks).map(normalizeBlock),
  };
}

function normalizePage(p: AnyRec): SurveyPage {
  return {
    title: p?.title ?? 'Seite',
    sections: toArr(p?.sections).map(normalizeSection),
  };
}

export function normalizeSurveySchema(input: AnyRec): SurveySchema {
  if (!input || typeof input !== 'object') return { title: 'Erhebung', pages: [] };
  const candidate = (input.survey ?? (Array.isArray(input.surveys) ? input.surveys[0] : input)) as AnyRec;
  const pages = toArr(candidate?.pages ?? candidate?.page).map(normalizePage);
  return { title: candidate?.title ?? 'Erhebung', pages };
}
