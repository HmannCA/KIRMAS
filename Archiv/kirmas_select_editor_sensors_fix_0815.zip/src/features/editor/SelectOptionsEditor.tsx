import React from 'react';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable, arrayMove } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

type Opt = string | { value: string; label: string };
type Row = { id: string; value: string; label: string };

function slugify(s: string): string {
  return (s || '')
    .trim()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[ß]/g, 'ss')
    .replace(/[ä]/g, 'ae')
    .replace(/[ö]/g, 'oe')
    .replace(/[ü]/g, 'ue')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function tinyId(len = 6): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let out = '';
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

function toObjects(value: Opt[]): { value: string; label: string }[] {
  const out: { value: string; label: string }[] = [];
  for (const o of (value || [])) {
    if (o == null) continue;
    if (typeof o === 'string') out.push({ value: slugify(o), label: o });
    else {
      const v = (o.value ?? slugify(o.label ?? 'option')) + '';
      const l = (o.label ?? o.value ?? '') + '';
      out.push({ value: v, label: l });
    }
  }
  return out;
}

function rowsFromValue(value: Opt[]): Row[] {
  const objs = toObjects(value || []);
  return objs.map((it, i) => ({ id: 'r_' + i + '_' + tinyId(), ...it }));
}

export default function SelectOptionsEditor({
  value,
  onChange
}:{
  value: Opt[];
  onChange: (next: { value: string; label: string }[]) => void;
}){
  // Modi
  const [mode, setMode] = React.useState<'advanced'|'simple'>(() => {
    return (value || []).some(v => typeof v === 'object') ? 'advanced' : 'simple';
  });

  // Einfügeposition
  const [insertAt, setInsertAt] = React.useState<'start'|'end'>('end');

  // Interner Zustand
  const [rows, setRows] = React.useState<Row[]>(() => rowsFromValue(value || []));
  const [text, setText] = React.useState<string>(() => {
    const objs = toObjects(value || []);
    return objs.map(r => (r.label === r.value ? r.label : `${r.label} | ${r.value}`)).join('\n');
  });

  // Bei Feldwechsel: Zustand aus neuen Props übernehmen (ohne Parent-Update)
  React.useEffect(() => {
    setRows(rowsFromValue(value || []));
    const objs = toObjects(value || []);
    setText(objs.map(r => (r.label === r.value ? r.label : `${r.label} | ${r.value}`)).join('\n'));
    setMode((value || []).some(v => typeof v === 'object') ? 'advanced' : 'simple');
  }, [value]);

  // DnD - SENSORS: nur einmal definieren
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  function onDragEnd(e: any){
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const oldIndex = rows.findIndex(r => r.id === active.id);
    const newIndex = rows.findIndex(r => r.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;
    const next = arrayMove(rows, oldIndex, newIndex);
    setRows(next);
    onChange(next.map(r => ({ value: r.value, label: r.label })));
  }

  // CRUD + Sort triggern Parent-Update direkt, ohne useEffect-Schleifen
  function addRow(){
    const base = { label: 'Option', value: 'option' };
    const r: Row = { id: 'r_new_' + tinyId(), ...base };
    const next = insertAt === 'start' ? [r, ...rows] : [...rows, r];
    setRows(next);
    onChange(next.map(x => ({ value: x.value, label: x.label })));
  }
  function removeRow(i:number){
    const next = rows.filter((_,idx)=> idx!==i);
    setRows(next);
    onChange(next.map(x => ({ value: x.value, label: x.label })));
  }
  function updateRow(i:number, patch: Partial<{label:string; value:string}>){
    const next = rows.map((row,idx)=> idx===i ? { ...row, ...patch } : row);
    setRows(next);
    onChange(next.map(x => ({ value: x.value, label: x.label })));
  }
  function sortBy(by:'label'|'value', dir:'asc'|'desc'){
    const next = [...rows].sort((a,b)=> {
      const A = (a[by] || '').toLowerCase();
      const B = (b[by] || '').toLowerCase();
      if (A < B) return dir==='asc' ? -1 : 1;
      if (A > B) return dir==='asc' ? 1 : -1;
      return 0;
    });
    setRows(next);
    onChange(next.map(x => ({ value: x.value, label: x.label })));
  }

  // Import
  async function importFile(file: File, mode:'append'|'replace'){
    const name = file.name.toLowerCase();
    const buf = await file.arrayBuffer();
    let pairs: {label:string; value:string}[] = [];

    if (name.endsWith('.csv') || name.endsWith('.txt')) {
      const text = new TextDecoder('utf-8').decode(buf);
      const lines = text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
      for (const line of lines) {
        const csv = line.split(/;|,|\t/);
        if (csv.length >= 2) {
          const label = csv[0].trim();
          const value = (csv[1] || '').trim() || slugify(label);
          pairs.push({ label, value });
        } else {
          const m = line.match(/^(.+?)[\|=](.+)$/);
          if (m) { const label = m[1].trim(); const value = (m[2]||'').trim() || slugify(label); pairs.push({label,value}); }
          else { const label = line; pairs.push({ label, value: slugify(label) }); }
        }
      }
    } else if (name.endsWith('.xlsx')) {
      try {
        const XLSX = await import('xlsx');
        const wb = XLSX.read(buf, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];
        for (const row of rows) {
          if (!row || row.length===0) continue;
          const label = String(row[0] ?? '').trim();
          if (!label) continue;
          const value = String(row[1] ?? '').trim() || slugify(label);
          pairs.push({ label, value });
        }
      } catch (e) {
        alert('XLSX-Import erfordert das Paket "xlsx". Bitte installieren: npm i xlsx');
        return;
      }
    } else {
      alert('Bitte CSV, TXT oder XLSX auswählen.');
      return;
    }

    const newRows: Row[] = pairs.map((p, i) => ({ id:'r_imp_' + i + '_' + tinyId(), ...p }));
    const next = mode==='replace' ? newRows : [...rows, ...newRows];
    setRows(next);
    onChange(next.map(x => ({ value: x.value, label: x.label })));
  }

  const fileRefAppend = React.useRef<HTMLInputElement>(null);
  const fileRefReplace = React.useRef<HTMLInputElement>(null);

  const toolbar = (
    <div className="row" style={{ gap:8, alignItems:'center', flexWrap:'wrap' }}>
      <div className="row" style={{gap:6, alignItems:'center'}}>
        <span style={{fontSize:12, color:'#475467'}}>Einfügeposition:</span>
        <label className="row" style={{gap:4}}>
          <input type="radio" checked={insertAt==='start'} onChange={()=>setInsertAt('start')} />
          <span>Anfang</span>
        </label>
        <label className="row" style={{gap:4}}>
          <input type="radio" checked={insertAt==='end'} onChange={()=>setInsertAt('end')} />
          <span>Ende</span>
        </label>
      </div>
      <button className="btn" onClick={addRow}>+ Option</button>
      <span style={{marginLeft:8, fontSize:12, color:'#475467'}}>Sortieren:</span>
      <button className="btn" onClick={()=>sortBy('label','asc')}>Label ↑</button>
      <button className="btn" onClick={()=>sortBy('label','desc')}>Label ↓</button>
      <button className="btn" onClick={()=>sortBy('value','asc')}>Value ↑</button>
      <button className="btn" onClick={()=>sortBy('value','desc')}>Value ↓</button>

      <span style={{marginLeft:8, fontSize:12, color:'#475467'}}>Import:</span>
      <input ref={fileRefAppend} type="file" accept=".csv,.txt,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style={{display:'none'}} onChange={e=>{ const f=e.target.files?.[0]; if(f) importFile(f,'append'); e.currentTarget.value=''; }} />
      <button className="btn" onClick={()=>fileRefAppend.current?.click()}>CSV/XLSX anhängen</button>
      <input ref={fileRefReplace} type="file" accept=".csv,.txt,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style={{display:'none'}} onChange={e=>{ const f=e.target.files?.[0]; if(f) importFile(f,'replace'); e.currentTarget.value=''; }} />
      <button className="btn" onClick={()=>fileRefReplace.current?.click()}>CSV/XLSX ersetzen</button>
    </div>
  );

  return (
    <div style={{display:'grid', gap:8}}>
      <div className="row" style={{ gap:8, alignItems:'center' }}>
        <label className="row" style={{ gap:6 }}>
          <input type="radio" checked={mode==='advanced'} onChange={()=>{ setMode('advanced'); onChange(rows.map(x=>({value:x.value,label:x.label}))); }} />
          <span>Erweitert (Label &amp; Value je Zeile, DnD)</span>
        </label>
        <label className="row" style={{ gap:6 }}>
          <input type="radio" checked={mode==='simple'} onChange={()=>{ setMode('simple'); onChange(toObjects(value || []).map(x=>({value:x.value,label:x.label}))); }} />
          <span>Einfach (eine Option je Zeile)</span>
        </label>
      </div>

      {mode==='advanced' ? (
        <div style={{border:'1px solid #EAECF0', borderRadius:8, padding:8}}>
          {toolbar}
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
            <SortableContext items={rows.map(r=>r.id)} strategy={verticalListSortingStrategy}>
              <table className="kirmas-table" style={{ width:'100%', borderCollapse:'collapse', marginTop:8 }}>
                <colgroup>
                  <col style={{width:'4%'}} />
                  <col style={{width:'48%'}} />
                  <col style={{width:'38%'}} />
                  <col style={{width:'10%'}} />
                </colgroup>
                <thead>
                  <tr><th></th><th>Label</th><th>Value</th><th></th></tr>
                </thead>
                <tbody>
                  {rows.map((r, i) => (
                    <SortableRow key={r.id} row={r} index={i}
                      onRemove={()=>removeRow(i)}
                      onChange={(p)=>updateRow(i,p)} />
                  ))}
                </tbody>
              </table>
            </SortableContext>
          </DndContext>
        </div>
      ) : (
        <textarea
          className="kirmas-textarea"
          placeholder="Eine Option pro Zeile. Optional: „Label | value“"
          value={text}
          onChange={e=>{
            const t = e.target.value;
            setText(t);
            const list: {value:string; label:string}[] = [];
            for (const rawLine of (t || '').split(/\r?\n/)) {
              const line = rawLine.trim();
              if (!line) continue;
              const m = line.match(/^(.+?)[\|=](.+)$/);
              if (m) {
                const label = m[1].trim();
                const value = (m[2] || '').trim() || slugify(label);
                list.push({ label, value });
              } else {
                const label = line;
                list.push({ label, value: slugify(label) });
              }
            }
            onChange(list);
          }}
        />
      )}
    </div>
  );
}

function SortableRow({ row, index, onRemove, onChange }:{ row: Row; index: number; onRemove: ()=>void; onChange: (p: Partial<Row>)=>void }){
  const {attributes, listeners, setNodeRef, transform, transition, isDragging} = useSortable({ id: row.id });
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
    background: isDragging ? '#F9FAFB' : undefined
  };
  return (
    <tr ref={setNodeRef} style={style}>
      <td>
        <button className="btn" aria-label="ziehen" {...attributes} {...listeners} title="Ziehen">
          ≡
        </button>
      </td>
      <td><input className="kirmas-input" value={row.label} onChange={e=>onChange({label:e.target.value})} /></td>
      <td><input className="kirmas-input" value={row.value} onChange={e=>onChange({value:e.target.value})} /></td>
      <td><button className="btn" onClick={onRemove}>–</button></td>
    </tr>
  );
}
