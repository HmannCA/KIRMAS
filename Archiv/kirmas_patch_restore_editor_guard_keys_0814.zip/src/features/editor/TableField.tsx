import React, { useMemo, useRef } from 'react'
import type { TableColumn, TableRow } from './TableFieldTypes'

export type { TableColumn, TableRow } from './TableFieldTypes'

function toCSV(rows: TableRow[], columns: TableColumn[]): string {
  const header = columns.map(c => c.key)
  const esc = (v: any) => {
    if (v === null || v === undefined) return ''
    const s = String(v)
    if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"'
    return s
  }
  const lines = [header.join(',')]
  for (const r of rows) {
    const vals = columns.map(c => {
      const v = r[c.key]
      if (c.type === 'checkbox') return v ? 'true' : 'false'
      return v ?? ''
    })
    lines.push(vals.map(esc).join(','))
  }
  return lines.join('\n')
}

function parseCSV(text: string): string[][] {
  const rows: string[][] = []
  let i = 0, field = '', inQuotes = false, row: string[] = []
  while (i < text.length) {
    const ch = text[i]
    if (inQuotes) {
      if (ch === '"') {
        if (text[i+1] === '"') { field += '"'; i += 2; continue }
        inQuotes = false; i++; continue
      } else { field += ch; i++; continue }
    } else {
      if (ch === '"') { inQuotes = true; i++; continue }
      if (ch === ',') { row.push(field); field=''; i++; continue }
      if (ch === '\n' || ch === '\r') {
        if (ch === '\r' && text[i+1] === '\n') i++
        row.push(field); rows.push(row); field=''; row=[]; i++; continue
      }
      field += ch; i++; continue
    }
  }
  row.push(field); rows.push(row)
  return rows.filter(r => !(r.length===1 && r[0]===''))
}

function normalizeBool(s: string): boolean {
  const t = s.trim().toLowerCase()
  return t==='true' || t==='1' || t==='yes' || t==='ja' || t==='wahr' || t==='x'
}

function parseNumberSmart(s: string): number | null {
  const t = s.trim().replace(',', '.')
  if (t==='') return null
  const n = Number(t)
  return Number.isFinite(n) ? n : null
}

function validateCell(col: TableColumn, value: any): string | null {
  if (col.required) {
    if (col.type === 'checkbox') {
      if (!value) return 'Pflicht: muss angehakt sein'
    } else if (value === null || value === undefined || String(value).trim() === '') {
      return 'Pflichtfeld'
    }
  }
  if (col.type === 'number') {
    if (value !== null && value !== undefined && String(value).trim() !== '') {
      const n = parseNumberSmart(String(value))
      if (n === null) return 'Ungültige Zahl'
      if (typeof col.min === 'number' && n < col.min) return `>= ${col.min}`
      if (typeof col.max === 'number' && n > col.max) return `<= ${col.max}`
    }
  }
  if (col.type === 'text' && col.pattern) {
    try {
      const re = new RegExp(col.pattern)
      if (value && !re.test(String(value))) return 'Muster nicht erfüllt'
    } catch {}
  }
  if ((col.type === 'select' || col.type === 'radio') && col.options && value) {
    if (!col.options.includes(String(value))) return 'Nicht in Optionen'
  }
  return null
}

function computeColPercents(columns: TableColumn[]): number[] {
  const manual: Array<number | null> = columns.map(c =>
    typeof c.widthPct === 'number' && c.widthPct > 0
      ? Math.min(100, Math.max(0, c.widthPct))
      : null
  )
  // WICHTIG: Initialwert 0 + generischer Typ -> Akkumulator ist sicher number
  const sumManual = manual.reduce<number>((acc, v) => acc + (v ?? 0), 0)
  const autoCount = manual.filter(v => v === null).length
  const leftover = Math.max(0, 100 - sumManual)
  const autoWidth = autoCount > 0 ? leftover / autoCount : 0
  return manual.map(v => v ?? autoWidth)
}


export default function TableField({
  columns,
  value,
  onChange,
  nameForExport
}:{
  columns: TableColumn[]
  value: TableRow[]
  onChange: (rows: TableRow[]) => void
  nameForExport?: string
}){
  const rows = value || []
  const colKeyList = columns.map(c => c.key)
  const fileRefAppend = useRef<HTMLInputElement>(null)
  const fileRefReplace = useRef<HTMLInputElement>(null)

  function setCell(rIdx:number, key:string, v:any){
    const next = rows.map((r,i) => i===rIdx ? { ...r, [key]: v } : r)
    onChange(next)
  }
  function addRow(){
    const newRow: TableRow = {}
    for (const k of colKeyList) newRow[k] = ''
    onChange([...(rows||[]), newRow])
  }
  function removeRow(idx:number){
    const next = rows.slice(); next.splice(idx,1); onChange(next)
  }

  function exportCSV(){
    const csv = toCSV(rows, columns)
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    const fname = (nameForExport || 'tabelle') + '.csv'
    a.href = url; a.download = fname; document.body.appendChild(a); a.click(); a.remove()
    URL.revokeObjectURL(url)
  }

  function handleImport(file: File, mode: 'append'|'replace'){
    const fr = new FileReader()
    fr.onload = () => {
      const text = String(fr.result || '')
      const matrix = parseCSV(text)
      if (matrix.length === 0) return
      const header = matrix[0]
      const body = matrix.slice(1)
      const keyIdx: Record<string, number> = {}
      header.forEach((h, i) => keyIdx[h.trim()] = i)
      const mapped: TableRow[] = body.map(row => {
        const obj: TableRow = {}
        for (const c of columns) {
          const idx = keyIdx[c.key]
          if (idx === undefined) { obj[c.key] = ''; continue }
          const raw = row[idx] ?? ''
          if (c.type === 'checkbox') obj[c.key] = normalizeBool(String(raw))
          else if (c.type === 'number') obj[c.key] = String(raw)
          else obj[c.key] = String(raw)
        }
        return obj
      })
      onChange(mode==='replace' ? mapped : [ ...(rows||[]), ...mapped ])
    }
    fr.readAsText(file, 'utf-8')
  }

  const errors = useMemo(() => {
    const errMap: Record<string, Record<number, string | null>> = {}
    for (let ci=0; ci<columns.length; ci++){
      const c = columns[ci]
      errMap[c.key] = {}
      for (let ri=0; ri<rows.length; ri++){
        const v = rows[ri]?.[c.key]
        errMap[c.key][ri] = validateCell(c, v)
      }
    }
    return errMap
  }, [columns, rows])

  const errorCount = useMemo(() => {
    let n = 0
    for (const c of columns) for (let ri=0; ri<rows.length; ri++){
      if (errors[c.key]?.[ri]) n++
    }
    return n
  }, [errors, columns, rows])

  const percents = computeColPercents(columns)

  return (
    <div className="table-wrap">
      <table className="kirmas-table">
        <colgroup>
          {columns.map((c, i) => <col key={c.id} style={{ width: percents[i] + '%' }} />)}
          <col style={{ width: 42 }} />
        </colgroup>
        <thead>
          <tr>
            {columns.map((c,i) => <th key={c.id || c.key || i}>{c.label}{c.required && <span style={{color:'#b91c1c'}}> *</span>}</th>)}
            <th style={{width:1}}></th>
          </tr>
        </thead>
        <tbody>
          {(rows||[]).map((r, rIdx) => (
            <tr key={rIdx}>
              {columns.map(c => {
                const v = r[c.key]
                const err = errors[c.key]?.[rIdx] || null

                if (c.type === 'checkbox'){
                  return (
                    <td key={c.id || c.key}>
                      <input type="checkbox" checked={!!v} onChange={e=>setCell(rIdx, c.key, e.target.checked)} title={err || ''} />
                      {err && <div className="cell-err">{err}</div>}
                    </td>
                  )
                }
                if (c.type === 'select' || c.type === 'radio'){
                  const opts = c.options || []
                  return (
                    <td key={c.id || c.key}>
                      <select className={'kirmas-input' + (err ? ' invalid' : '')} value={v ?? ''} onChange={e=>setCell(rIdx, c.key, e.target.value)} title={err || ''}>
                        <option value=""></option>
                        {opts.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                      {err && <div className="cell-err">{err}</div>}
                    </td>
                  )
                }
                if (c.type === 'number'){
                  return (
                    <td key={c.id || c.key}>
                      <input
                        type="number"
                        className={'kirmas-input' + (err ? ' invalid' : '')}
                        value={v ?? ''}
                        onChange={e=>setCell(rIdx, c.key, e.target.value)}
                        title={err || ''}
                      />
                      {err && <div className="cell-err">{err}</div>}
                    </td>
                  )
                }
                return (
                  <td key={c.id || c.key}>
                    <input
                      type="text"
                      className={'kirmas-input' + (err ? ' invalid' : '')}
                      value={v ?? ''}
                      onChange={e=>setCell(rIdx, c.key, e.target.value)}
                      title={err || ''}
                    />
                    {err && <div className="cell-err">{err}</div>}
                  </td>
                )
              })}
              <td>
                <button className="btn" onClick={()=>removeRow(rIdx)}>–</button>
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td colSpan={columns.length+1}>
              <div className="row" style={{ flexWrap:'wrap', gap:8, alignItems:'center' }}>
                <button className="btn" onClick={addRow}>+ Zeile</button>
                <span style={{ marginLeft:'auto' }}></span>
                <button className="btn" onClick={exportCSV}>Export CSV</button>
                <input ref={fileRefAppend} type="file" accept=".csv,text/csv" style={{ display:'none' }} onChange={e=>{ const f=e.target.files?.[0]; if(f) handleImport(f, 'append'); e.currentTarget.value='' }} />
                <button className="btn" onClick={()=>fileRefAppend.current?.click()}>Import CSV (Anhängen)</button>
                <input ref={fileRefReplace} type="file" accept=".csv,text/csv" style={{ display:'none' }} onChange={e=>{ const f=e.target.files?.[0]; if(f) handleImport(f, 'replace'); e.currentTarget.value='' }} />
                <button className="btn" onClick={()=>fileRefReplace.current?.click()}>Import CSV (Ersetzen)</button>
                {errorCount>0 && <span className="warn">Fehler: {errorCount}</span>}
              </div>
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  )
}
