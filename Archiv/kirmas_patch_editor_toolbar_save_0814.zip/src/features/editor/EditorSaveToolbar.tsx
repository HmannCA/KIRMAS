
import React from 'react';
import { saveSurvey, updateSurvey } from '../ai/surveyApi';

type Props = {
  /** Liefert das aktuell bearbeitete Erhebungs-Schema aus dem Editor. */
  getSchema: () => any;
  /** Optional: zuletzt gespeichertes Survey (ID/Title), falls der Editor das schon kennt. */
  lastId?: string;
  lastTitle?: string;
  /** Callback nach erfolgreichem Speichern */
  onSaved?: (info: { id: string; title: string }) => void;
};

const btn: React.CSSProperties = { padding: '6px 10px', borderRadius: 8, border: '1px solid #D0D5DD', background: '#fff', cursor: 'pointer' };
const btnPrimary: React.CSSProperties = { ...btn, background: '#155EEF', borderColor: '#155EEF', color: 'white' };
const wrap: React.CSSProperties = { display: 'flex', gap: 8, alignItems: 'center' };

export default function EditorSaveToolbar({ getSchema, lastId, lastTitle, onSaved }: Props) {
  const [title, setTitle] = React.useState<string>(lastTitle || '');
  const [saving, setSaving] = React.useState(false);
  const [currentId, setCurrentId] = React.useState<string | undefined>(lastId || (typeof localStorage !== 'undefined' ? localStorage.getItem('kirmas:lastSurveyId') || undefined : undefined));

  React.useEffect(() => {
    if (lastTitle) setTitle(lastTitle);
    if (lastId) setCurrentId(lastId);
  }, [lastId, lastTitle]);

  async function doSave(update: boolean) {
    try {
      setSaving(true);
      const schema = getSchema();
      const finalTitle = (title || schema?.title || 'Erhebung').toString();
      let id = currentId;
      if (update && id) {
        const rec = await updateSurvey(id, schema, finalTitle);
        onSaved?.({ id: rec.id, title: rec.title });
      } else {
        const rec = await saveSurvey(schema, finalTitle);
        id = rec.id;
        setCurrentId(id);
        onSaved?.({ id: rec.id, title: rec.title });
      }
      if (typeof localStorage !== 'undefined' && id) {
        localStorage.setItem('kirmas:lastSurveyId', id);
        localStorage.setItem('kirmas:lastSurveyTitle', finalTitle);
      }
      alert('Erhebung gespeichert.');
    } catch (e: any) {
      alert('Speichern fehlgeschlagen: ' + (e?.message || String(e)));
    } finally {
      setSaving(false);
    }
  }

  // Strg/Cmd+S -> Speichern (Update, wenn id vorhanden, sonst Neu)
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        doSave(Boolean(currentId));
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [currentId, title, getSchema]);

  return (
    <div style={wrap}>
      <input
        value={title}
        onChange={e => setTitle(e.target.value)}
        placeholder="Titel der Erhebung …"
        style={{ padding: '6px 8px', borderRadius: 8, border: '1px solid #D0D5DD', minWidth: 260 }}
      />
      <button onClick={() => doSave(Boolean(currentId))} disabled={saving} style={btnPrimary}>
        {saving ? 'Speichere…' : currentId ? 'Speichern' : 'Speichern (neu)'}
      </button>
      <button onClick={() => doSave(false)} disabled={saving} style={btn}>Speichern unter …</button>
    </div>
  );
}
