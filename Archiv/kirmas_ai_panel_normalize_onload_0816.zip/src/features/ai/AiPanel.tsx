
import React from 'react';

export type SurveySchema = any;

export type AiPanelProps = {
  open: boolean;
  onClose: () => void;
  getSchema: () => SurveySchema;
  onApply: (next: SurveySchema, mode: 'replace'|'append'|'integrate') => void;
  onLoad?: (payload: { id: string; title: string; version?: number; schema: SurveySchema }) => void;
};

type Provider = 'openai'|'gemini';
type Mode = 'replace'|'append'|'integrate';
type SavedItem = { id: string; title: string; version?: number; updatedAt?: string };

const styles = {
  overlay: { position: 'fixed' as const, top: 0, right: 0, bottom: 0, width: '480px', maxWidth: '100vw', background: '#FFFFFF', borderLeft: '1px solid #EAECF0', boxShadow: '-8px 0 24px rgba(16,24,40,0.08)', zIndex: 50, display: 'flex', flexDirection: 'column' as const },
  header: { padding: '12px 16px', borderBottom: '1px solid #EAECF0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
  title: { fontWeight: 600, fontSize: 16, color: '#101828' },
  body: { padding: 16, overflowY: 'auto' as const, display: 'grid', gap: 12 },
  label: { fontSize: 12, color: '#475467', marginBottom: 4 },
  select: { width: '100%', border: '1px solid #D0D5DD', borderRadius: 8, padding: '8px 10px', background: '#fff' },
  textarea: { width: '100%', minHeight: 120, border: '1px solid #D0D5DD', borderRadius: 8, padding: 10, resize: 'vertical' as const },
  row: { display: 'flex', gap: 8, alignItems: 'center' },
  col: { display: 'grid', gap: 6 },
  section: { display: 'grid', gap: 8, border: '1px solid #EAECF0', borderRadius: 10, padding: 12 },
  card: { border: '1px solid #EAECF0', borderRadius: 10, padding: 12 },
  small: { fontSize: 12, color: '#475467' },
  primary: { background: '#0B5ED7', color: '#fff', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' },
  subtle: { background: '#F2F4F7', color: '#344054', border: 0, borderRadius: 8, padding: '8px 12px', cursor: 'pointer' },
  listItem: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 8, borderBottom: '1px solid #F2F4F7' },
  busy: { position: 'absolute' as const, inset: 0, background: 'rgba(16,24,40,0.55)', display: 'grid', placeItems: 'center', color: '#fff' },
  busyCard: { background: '#0B5ED7', borderRadius: 12, padding: 16, width: '88%', maxWidth: 420, display: 'grid', gap: 8, textAlign: 'center' as const, animation: 'pulse 1.8s ease-in-out infinite' }
};

const BUSY_LINES = [
  'Die KI analysiert Ihre Vorgaben …',
  'Dokumente werden aufbereitet …',
  'Feldstruktur wird modelliert …',
  'Abhängigkeiten & Sichtbarkeiten werden geprüft …',
  'Datenbankkonformität wird sichergestellt …',
  'Erhebung wird qualitätsgesichert …'
];

function modelsFor(p: Provider) {
  return p === 'openai' ? ['gpt-5', 'gpt-4o'] : ['gemini-2.5-pro', 'gemini-2.5-flash'];
}

/** -------- Schema Normalisierung (defensiv) -------- */
function tinyId() { return Math.random().toString(36).slice(2, 8); }
function slug(s: any) {
  return String(s ?? '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
}
function ensureArray<T=any>(v: any): T[] { return Array.isArray(v) ? v as T[] : (v==null ? [] : [v]); }

function normalizeOptions(opts: any): any[] {
  if (!opts) return [];
  if (Array.isArray(opts)) {
    return opts.map((o, i) => {
      if (o && typeof o === 'object') {
        const value = o.value ?? o.key ?? slug(o.label ?? o.text ?? `opt_${i}`);
        const label = o.label ?? o.text ?? String(value);
        const id = o.id ?? `opt_${i}_${tinyId()}`;
        return { id, value: String(value), label: String(label) };
      }
      const value = slug(o);
      const label = String(o);
      return { id: `opt_${i}_${tinyId()}`, value, label };
    });
  }
  const arr: any[] = [];
  for (const [k, v] of Object.entries(opts)) {
    arr.push({ id: `opt_${arr.length}_${tinyId()}`, value: String(k), label: String(v) });
  }
  return arr;
}

function normalizeField(f: any, idx: number) {
  const type0 = String(f?.type ?? f?.fieldType ?? 'text').toLowerCase();
  const type = type0 === 'dropdown' ? 'select' : type0;
  const id = f?.id ?? `fld_${idx}_${tinyId()}`;
  const name = f?.name ?? slug(f?.label ?? f?.title ?? id);
  const label = f?.label ?? f?.title ?? name;
  const width = Number.isFinite(Number(f?.width)) ? Number(f?.width) : 12;
  const base: any = { id, type, name, label, width };

  if (type === 'select') {
    const options = normalizeOptions(f?.options ?? f?.choices ?? f?.items);
    return { ...base, options };
  }
  if (type === 'table') {
    const rawCols = ensureArray(f?.columns ?? f?.cols ?? f?.fields);
    const columns = rawCols.map((c: any, i: number) => {
      const cid = c?.id ?? `col_${i}_${tinyId()}`;
      const key = c?.key ?? c?.name ?? slug(c?.label ?? c?.title ?? cid);
      const label = c?.label ?? c?.title ?? key;
      const ctype = String(c?.type ?? 'text').toLowerCase();
      return { id: cid, key, label, type: ctype };
    });
    return { ...base, columns };
  }
  return { ...base };
}

function normalizeSurveySchema(input: any): any {
  if (!input || typeof input !== 'object') return { title: 'Ohne Titel', pages: [] };
  let schema = input.schema || input.definition || input.data || input;
  const title = input.title ?? schema.title ?? 'Ohne Titel';
  let pages = schema.pages;
  let sections = schema.sections;
  let fields = schema.fields;
  const out: any = { title, pages: [] as any[] };

  if (Array.isArray(pages)) {
    out.pages = pages.map((p: any, pi: number) => {
      const pid = p?.id ?? `pg_${pi}_${tinyId()}`;
      const ptitle = p?.title ?? `Seite ${pi+1}`;
      const pSections = Array.isArray(p?.sections) ? p.sections : (Array.isArray(p?.fields) ? [{ id: `sec_${pi}_0_${tinyId()}`, title: 'Abschnitt', fields: p.fields }] : []);
      const normSecs = pSections.map((s: any, si: number) => {
        const sid = s?.id ?? `sec_${pi}_${si}_${tinyId()}`;
        const stitle = s?.title ?? `Abschnitt ${si+1}`;
        const sfields = ensureArray(s?.fields).map((f, fi) => normalizeField(f, fi));
        return { id: sid, title: stitle, fields: sfields };
      });
      return { id: pid, title: ptitle, sections: normSecs };
    });
    return out;
  }

  if (Array.isArray(sections)) {
    const pid = `pg_0_${tinyId()}`;
    const normSecs = sections.map((s: any, si: number) => {
      const sid = s?.id ?? `sec_0_${si}_${tinyId()}`;
      const stitle = s?.title ?? `Abschnitt ${si+1}`;
      const sfields = ensureArray(s?.fields).map((f, fi) => normalizeField(f, fi));
      return { id: sid, title: stitle, fields: sfields };
    });
    out.pages = [{ id: pid, title, sections: normSecs }];
    return out;
  }

  if (Array.isArray(fields)) {
    const pid = `pg_0_${tinyId()}`;
    const sid = `sec_0_${tinyId()}`;
    const normFields = fields.map((f: any, fi: number) => normalizeField(f, fi));
    out.pages = [{ id: pid, title, sections: [{ id: sid, title: 'Abschnitt', fields: normFields }] }];
    return out;
  }
  return out;
}
/** -------- Ende Normalisierung -------- */

async function fetchText(url: string) {
  const r = await fetch(url, { headers: { 'accept': 'application/json, text/plain;q=0.9, */*;q=0.8' }});
  if (!r.ok) throw new Error(r.status + ' ' + r.statusText);
  const text = await r.text();
  const maybeJSON = (() => { try { return JSON.parse(text); } catch { return null; } })();
  if (maybeJSON) return { text: JSON.stringify(maybeJSON), ct: 'application/json' };
  return { text, ct: 'text/plain' };
}

function tryParseJson(text: string) {
  try { return JSON.parse(text); } catch { return null; }
}

function coerceArray(anyRows: any): any[] {
  if (Array.isArray(anyRows)) return anyRows;
  if (anyRows && typeof anyRows === 'object') {
    for (const k of ['items','rows','data','list']) {
      if (Array.isArray((anyRows as any)[k])) return (anyRows as any)[k];
    }
    const vals = Object.values(anyRows);
    if (vals.length && vals.every(v => v && typeof v === 'object')) return vals as any[];
  }
  return [];
}

async function loadJsonFromCandidates(paths: string[]) {
  let lastErr: any;
  for (const p of paths) {
    try {
      const { text } = await fetchText(p);
      const maybe = tryParseJson(text);
      if (maybe == null) { lastErr = new Error('Kein gültiges JSON @ ' + p); continue; }
      return maybe;
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error('Keine JSON-Quelle gefunden.');
}

export default function AiPanel({ open, onClose, getSchema, onApply, onLoad }: AiPanelProps) {
  const [provider, setProvider] = React.useState<Provider>('openai');
  const [model, setModel] = React.useState<string>('gpt-5');
  const [mode, setMode] = React.useState<Mode>('replace');
  const [prompt, setPrompt] = React.useState<string>('Bitte die Erhebung präzise und datenbanktauglich modellieren. Wenn sinnvoll, in logisch getrennte Teil-Erhebungen splitten.');

  const [busy, setBusy] = React.useState(false);
  const [busyLine, setBusyLine] = React.useState(BUSY_LINES[0]);

  const [saved, setSaved] = React.useState<SavedItem[]>([]);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!busy) return;
    let i = 0;
    const id = setInterval(() => {
      i = (i + 1) % BUSY_LINES.length;
      setBusyLine(BUSY_LINES[i]);
    }, 1200 + Math.floor(Math.random() * 800));
    return () => clearInterval(id);
  }, [busy]);

  React.useEffect(() => { if (open) refreshList(); }, [open]);
  React.useEffect(() => { setModel(modelsFor(provider)[0]); }, [provider]);

  async function refreshList() {
    try {
      setError(null);
      const candidates = [
        '/api/surveys',
        '/api/devstore/surveys',
        '/api/devstore/surveys/list',
        '/devstore/surveys/index.json',
        '/devstore/surveys.json',
        '/devstore/index/surveys.json'
      ];
      const raw = await loadJsonFromCandidates(candidates);
      const rows = coerceArray(raw);
      const norm = rows
        .filter((x: any) => x && (x.id || x.ID) && (x.title || x.name))
        .map((x: any) => ({
          id: String(x.id || x.ID),
          title: String(x.title || x.name || x.schema?.title || x.definition?.title || 'Ohne Titel'),
          version: (x.version ?? x.schema?.version ?? x.definition?.version) ?? undefined,
          updatedAt: x.updatedAt ?? x.mtime ?? undefined
        }));
      norm.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
      setSaved(norm);
    } catch (e: any) {
      console.warn('refreshList failed', e);
      setError('Konnte gespeicherte Erhebungen nicht laden.');
      setSaved([]);
    }
  }

  async function handleLoad(id: string) {
    try {
      setError(null);
      const detailCandidates = [
        `/api/surveys/${encodeURIComponent(id)}`,
        `/api/devstore/surveys/${encodeURIComponent(id)}`,
        `/api/devstore/surveys/get?id=${encodeURIComponent(id)}`,
        `/devstore/surveys/${encodeURIComponent(id)}.json`
      ];
      const payload: any = await loadJsonFromCandidates(detailCandidates);
      const title = String(payload.title || payload.name || payload.schema?.title || 'Ohne Titel');
      const version = payload.version ?? payload.schema?.version ?? undefined;
      const schemaRaw = payload.schema || payload.definition || payload.data || payload;
      const schema = normalizeSurveySchema(schemaRaw);
      if (onLoad) onLoad({ id, title, version, schema });
      else onApply({ ...schema, __id: id, __title: title, __version: version }, 'replace');
      onClose();
    } catch (e: any) {
      console.error(e);
      setError('Konnte Erhebung nicht laden.');
    }
  }

  async function runSynthesis() {
    setBusy(true);
    setError(null);
    try {
      const current = getSchema();
      const body = { prompt, mode, provider, model, schema: current };
      const r = await fetch('/api/ai/synthesize?mode=' + encodeURIComponent(mode), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
      });
      if (!r.ok) {
        if (r.status === 422) throw new Error('KI-Antwort war nicht gültiges JSON (422).');
        throw new Error('Serverfehler: ' + r.status + ' ' + r.statusText);
      }
      const data = await r.json();
      if (!data || !data.schema) throw new Error('Server lieferte kein { schema }.');
      const normalized = normalizeSurveySchema(data.schema);
      onApply(normalized, mode);
    } catch (e: any) {
      console.error(e);
      setError(e?.message || 'Unbekannter Fehler bei der KI-Synthese.');
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;

  return (
    <aside style={styles.overlay} role="dialog" aria-label="KI-Assistent">
      <div style={styles.header}>
        <div style={styles.title}>KI-Assistent</div>
        <div className="row" style={{ display:'flex', gap:8 }}>
          <button style={styles.subtle} onClick={onClose}>Schließen</button>
          <button style={styles.primary} onClick={runSynthesis}>Erhebung erzeugen</button>
        </div>
      </div>

      <div style={styles.body}>
        <div style={styles.section}>
          <div style={styles.row}>
            <div style={{ flex: 1 }}>
              <div style={styles.label}>KI-Anbieter</div>
              <select style={styles.select} value={provider} onChange={e => setProvider(e.target.value as Provider)}>
                <option value="openai">OpenAI</option>
                <option value="gemini">Google Gemini</option>
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <div style={styles.label}>Modell</div>
              <select style={styles.select} value={model} onChange={e => setModel(e.target.value)}>
                {modelsFor(provider).map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </div>

          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='replace'} onChange={()=>setMode('replace')} />
              <span>Neu erstellen (ersetzen)</span>
            </label>
          </div>
          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='append'} onChange={()=>setMode('append')} />
              <span>An bestehende Erhebung anhängen</span>
            </label>
          </div>
          <div style={styles.row}>
            <label className="row" style={{ display:'flex', gap:6, alignItems:'center' }}>
              <input type="radio" checked={mode==='integrate'} onChange={()=>setMode('integrate')} />
              <span>Intelligent in bestehende integrieren</span>
            </label>
          </div>

          <div style={styles.col}>
            <div style={styles.label}>Auftrag an die KI</div>
            <textarea style={styles.textarea} value={prompt} onChange={e => setPrompt(e.target.value)}
              placeholder="Beschreibe das Ziel, Dokumente etc. (Erstellung kann einige Minuten dauern)." />
            <div style={styles.small}>Hinweis: Die Erstellung kann einige Minuten dauern. Das System bleibt währenddessen aktiv – bitte nicht schließen.</div>
          </div>
        </div>

        <div style={styles.section}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontWeight: 600, color: '#101828' }}>Gespeicherte Erhebungen</div>
            <button style={styles.subtle} onClick={refreshList}>Aktualisieren</button>
          </div>
          <div style={styles.card}>
            {error && <div style={{ color:'#D92D20', marginBottom:8 }}>{error}</div>}
            <div style={{ display:'grid' }}>
              {saved.length === 0 && <div style={styles.small}>Keine Erhebungen gefunden. Prüfe API /api/devstore/surveys oder statisch /devstore/surveys/index.json.</div>}
              {saved.map(item => (
                <div key={item.id} style={styles.listItem}>
                  <div style={{ display:'grid' }}>
                    <div style={{ fontWeight: 600 }}>{item.title}</div>
                    <div style={{ fontSize: 12, color:'#475467' }}>
                      ID: <span style={{ fontFamily:'monospace' }}>{item.id}</span>
                      {item.version != null && <span> · Version {item.version}</span>}
                      {item.updatedAt && <span> · {new Date(item.updatedAt).toLocaleString()}</span>}
                    </div>
                  </div>
                  <button style={styles.primary} onClick={()=>handleLoad(item.id)}>Laden</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {busy && (
        <div style={styles.busy}>
          <div style={styles.busyCard as any}>
            <div style={{ fontWeight: 700 }}>KI arbeitet …</div>
            <div>{BUSY_LINES[0]}</div>
            <div style={{ fontSize: 12, opacity: 0.9 }}>Bitte haben Sie einen Moment Geduld – die Erstellung kann einige Minuten dauern.</div>
          </div>
        </div>
      )}
    </aside>
  );
}
