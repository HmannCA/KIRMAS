
export type SurveyMeta = { id: string; title: string; createdAt: string; updatedAt: string };
export type SurveyRecord = { id: string; title: string; schema: any; createdAt: string; updatedAt: string };

export async function listSurveys(query = ''): Promise<SurveyMeta[]> {
  const u = '/api/surveys' + (query ? `?query=${encodeURIComponent(query)}` : '');
  const res = await fetch(u);
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || res.statusText);
  return data.items as SurveyMeta[];
}

export async function getSurvey(id: string): Promise<SurveyRecord> {
  const res = await fetch(`/api/surveys/${id}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || res.statusText);
  return data.record as SurveyRecord;
}

export async function saveSurvey(schema: any, title?: string): Promise<SurveyRecord> {
  const res = await fetch('/api/surveys', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, schema })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || res.statusText);
  return data.record as SurveyRecord;
}

export async function updateSurvey(id: string, schema: any, title?: string): Promise<SurveyRecord> {
  const res = await fetch(`/api/surveys/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, schema })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.error || res.statusText);
  return data.record as SurveyRecord;
}

export async function deleteSurvey(id: string): Promise<void> {
  const res = await fetch(`/api/surveys/${id}`, { method: 'DELETE' });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data?.error || res.statusText);
  }
}
