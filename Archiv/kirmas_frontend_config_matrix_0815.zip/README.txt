# Frontend Config Matrix (React 18.3 + Vite 5)

1) Ensure deps (as discussed):
   react/react-dom 18.3.x, vite 5.x, @vitejs/plugin-react 4.x

2) Replace/merge `vite.config.ts` and `tsconfig.json` with the files in this zip.
   - They enforce JSX automatic runtime and consistent dev transform.

3) Clear caches and reinstall (Windows CMD):
   rmdir /s /q node_modules
   del package-lock.json
   rmdir /s /q node_modules\.vite
   npm i
   npm run dev

4) Verify no duplicate React:
   npm ls react react-dom @vitejs/plugin-react vite

If the "Expected static flag was missing" warning persists, it typically means a second copy of React
is being pulled in via a linked package. In that case:
   - search your repo for another package.json referencing react/react-dom
   - or run `npm dedupe`
