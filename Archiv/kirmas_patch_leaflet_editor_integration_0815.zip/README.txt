# Patch: Leaflet Integration (Vite)

- `src/features/editor/KirmasEditor.tsx`:
  * Entfernt Marker-Icon-Imports aus Leaflet
  * Fügt `import './leaflet.setup'` hinzu

- `src/features/editor/leaflet.setup.ts`:
  * Setzt Standard-Marker-Icons korrekt via Vite-Asset-URLs

Stelle außerdem sicher, dass in `src/main.tsx` einmalig die CSS geladen wird:
  import 'leaflet/dist/leaflet.css';
